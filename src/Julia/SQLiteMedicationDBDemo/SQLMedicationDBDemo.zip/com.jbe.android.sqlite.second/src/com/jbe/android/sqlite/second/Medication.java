/**
 * Medication.java
 * 
 * @author Julia Edwards
 * @date March, 2014
 * 
 * Database model class that contains the data we will save in the database 
 * and show in the user interface.
 * 
 * Based on tutorial at: http://www.vogella.com/tutorials/AndroidSQLite/article.html#overview_sqlite
 * 
 */
package com.jbe.android.sqlite.second;

public class Medication {
	  private long id;
	  //The generic name
	  private String name;
	  //The dosage
	  private long dosage;
	  //The units of the dosage (i.e. "mg")
	  private String units;
	  
	  public Medication(){
	  }

	  public Medication(String name, long dosage, String units) {
		  this.name = name;
		  this.dosage = dosage;
		  this.units = units;
	  }
	  
	  public long getId() {
	    return id;
	  }

	  public void setId(long id) {
	    this.id = id;
	  }

	  public String getName() {
	    return name;
	  }

	  public void setName(String name) {
	    this.name = name;
	  }
	  
	  public long getDosage() {
		    return dosage;
	  }

	  public void setDosage(long dosage) {
		  this.dosage = dosage;
	  }	
		  
	  public String getUnits() {
		  return units;
	  }

	  public void setUnits(String units) {
		  this.units = units;
	  }

	  // Will be used by the ArrayAdapter in the ListView
	  @Override
	  public String toString() {
	    return name+": "+Float.toString(dosage)+" "+units;
	  }
} 