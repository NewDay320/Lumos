/**
 * TestDatabaseActivity.java
 * 
 * @author Julia Edwards
 * @date March, 2014
 * 
 * The main activity that runs the Database test app.
 * 
 * Based on tutorial at: http://www.vogella.com/tutorials/AndroidSQLite/article.html#overview_sqlite
 * 
 */
package com.jbe.android.sqlite.second;

import com.jbe.first.R;

import java.util.List;
import java.util.Random;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;

public class TestDatabaseActivity extends ListActivity {
  private MedicationsDataSource datasource;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    datasource = new MedicationsDataSource(this);
    datasource.open();

    List<Medication> values = datasource.getAllMedications();

    // use the SimpleCursorAdapter to show the
    // elements in a ListView
    ArrayAdapter<Medication> adapter = new ArrayAdapter<Medication>(this,
        android.R.layout.simple_list_item_1, values);
    setListAdapter(adapter);
  }

  // Will be called via the onClick attribute
  // of the buttons in main.xml
  public void onClick(View view) {
    @SuppressWarnings("unchecked")
    ArrayAdapter<Medication> adapter = (ArrayAdapter<Medication>) getListAdapter();
    Medication medication = null;
    switch (view.getId()) {
    case R.id.add:
      Medication[] medications = new Medication[] {
    		  new Medication("Klonopin", 5, "mg"),
    		  new Medication("Klonopin", 10, "mg"),
    		  new Medication("Advair", 2, "inhalations")
      };
      int nextInt = new Random().nextInt(3);
      // save the new comment to the database
      medication = datasource.createMedication(medications[nextInt].getName(),
    		  medications[nextInt].getDosage(),
    		  medications[nextInt].getUnits());
      adapter.add(medication);
      break;
    case R.id.delete:
      if (getListAdapter().getCount() > 0) {
        medication = (Medication) getListAdapter().getItem(0);
        datasource.deleteMedication(medication);
        adapter.remove(medication);
      }
      break;
    }
    adapter.notifyDataSetChanged();
  }

  @Override
  protected void onResume() {
    datasource.open();
    super.onResume();
  }

  @Override
  protected void onPause() {
    datasource.close();
    super.onPause();
  }

} 