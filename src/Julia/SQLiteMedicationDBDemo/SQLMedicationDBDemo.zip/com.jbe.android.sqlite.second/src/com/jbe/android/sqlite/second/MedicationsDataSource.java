/**
 * MedicationsDataSource.java
 * 
 * @author Julia Edwards
 * @date March, 2014
 * 
 * This class is our data access object (DAO). The DAO is responsible for handling the
 * database connection and for accessing and modifying the data. It will also convert 
 * the database objects into real Java Objects, so that our user interface code does 
 * not have to deal with the persistence layer.
 * 
 * This DAO maintains the database connection and supports adding new comments and 
 * fetching all comments.
 * 
 * Based on tutorial at: http://www.vogella.com/tutorials/AndroidSQLite/article.html#overview_sqlite
 * 
 */

package com.jbe.android.sqlite.second;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class MedicationsDataSource {

  // Database fields
  private SQLiteDatabase database;
  private MySQLiteHelper dbHelper;
  private String[] allColumns = { MySQLiteHelper.COLUMN_ID,
      MySQLiteHelper.COLUMN_NAME, MySQLiteHelper.COLUMN_DOSAGE,
      MySQLiteHelper.COLUMN_UNITS };

  public MedicationsDataSource(Context context) {
    dbHelper = new MySQLiteHelper(context);
  }

  public void open() throws SQLException {
    database = dbHelper.getWritableDatabase();
  }

  public void close() {
    dbHelper.close();
  }

  public Medication createMedication(String name, long dosage, String units) {
    ContentValues values = new ContentValues();
    values.put(MySQLiteHelper.COLUMN_NAME, name);
    values.put(MySQLiteHelper.COLUMN_DOSAGE, dosage);
    values.put(MySQLiteHelper.COLUMN_UNITS, units);
    long insertId = database.insert(MySQLiteHelper.TABLE_MEDICATIONS, null,
        values);
    Cursor cursor = database.query(MySQLiteHelper.TABLE_MEDICATIONS,
        allColumns, MySQLiteHelper.COLUMN_ID + " = " + insertId, null,
        null, null, null);
    cursor.moveToFirst();
    Medication newMedication = cursorToMedication(cursor);
    cursor.close();
    return newMedication;
  }

  public void deleteMedication(Medication medication) {
    long id = medication.getId();
    System.out.println("Comment deleted with id: " + id);
    database.delete(MySQLiteHelper.TABLE_MEDICATIONS, MySQLiteHelper.COLUMN_ID
        + " = " + id, null);
  }

  public List<Medication> getAllMedications() {
    List<Medication> medications = new ArrayList<Medication>();

    Cursor cursor = database.query(MySQLiteHelper.TABLE_MEDICATIONS,
        allColumns, null, null, null, null, null);

    cursor.moveToFirst();
    while (!cursor.isAfterLast()) {
      Medication medication = cursorToMedication(cursor);
      medications.add(medication);
      cursor.moveToNext();
    }
    // make sure to close the cursor
    cursor.close();
    return medications;
  }

  private Medication cursorToMedication(Cursor cursor) {
    Medication medication = new Medication();
    medication.setId(cursor.getLong(0));
    medication.setName(cursor.getString(1));
    medication.setDosage(cursor.getLong(2));
    medication.setUnits(cursor.getString(3));
    return medication;
  }
} 