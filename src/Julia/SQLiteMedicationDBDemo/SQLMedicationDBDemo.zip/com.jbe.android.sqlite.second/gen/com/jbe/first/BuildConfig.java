/** Automatically generated file. DO NOT MODIFY */
package com.jbe.first;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}